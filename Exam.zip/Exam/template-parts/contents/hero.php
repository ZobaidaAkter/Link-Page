<!-- hero part start -->
<section class="container text-center mt-5 hero">
    <div class="row">
        <?php dynamic_sidebar('herotitle');?>
    </div>
    <div class="row mt-5">
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('herocard1');?>
        </div>
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('herocard2');?>
        </div>
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('herocard3');?>
        </div>
        </div>
    </div>
</section>
<!-- hero part end -->